#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# KlikTahu — kendali penuh dari kantor agen (tanpa perlu Anda menyentuh GitHub)
#
#   export GH_TOKEN=...        # token GitHub (scope: repo + workflow)
#   export GH_USER=...         # username GitHub
#   bash tools/gh_control.sh all          # buat repo -> push -> render -> tarik hasil
#
#   bash tools/gh_control.sh push         # hanya push perubahan
#   bash tools/gh_control.sh render 12 4  # jalankan workflow (potongan × proses)
#   bash tools/gh_control.sh watch        # pantau sampai selesai
#   bash tools/gh_control.sh fetch        # unduh hasil terbaru ke /home/user
#   bash tools/gh_control.sh list         # daftar repo yang ada (repo lain jangan diganggu)
# ---------------------------------------------------------------------------
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
REPO="${REPO:-kliktahu-shorts}"                     # repo TERPISAH, selalu baru
API="https://api.github.com"
EPISODE="${EPISODE:-ep24_bulan_merah}"
: "${GH_TOKEN:?set GH_TOKEN (personal access token: repo + workflow)}"
: "${GH_USER:?set GH_USER (username GitHub)}"
AUTH=(-H "Authorization: Bearer $GH_TOKEN" -H "Accept: application/vnd.github+json" \
      -H "X-GitHub-Api-Version: 2022-11-28")

api() { curl -sS "${AUTH[@]}" "$@"; }

cmd_list()   { api "$API/user/repos?per_page=100" | python3 -c "import json,sys;[print(r['full_name'],'| private' if r['private'] else '| publik') for r in json.load(sys.stdin)]"; }

cmd_mkrepo() {
  api -o /tmp/mkrepo.json -w "%{http_code}\n" -X POST "$API/user/repos" \
      -d "{\"name\":\"$REPO\",\"private\":false,\"description\":\"KlikTahu shorts render pipeline (agen)\",\"auto_init\":false}" \
    | tail -1 | grep -E "20[0-9]" >/dev/null && echo "repo dibuat: $GH_USER/$REPO" || echo "repo sudah ada / gagal (cek /tmp/mkrepo.json)"
}

cmd_push() {
  [ -d .git ] || git init -q
  git config user.email "bot@kliktahu.local"; git config user.name "KlikTahu Bot"
  git add -A
  git -c commit.gpgsign=false commit -q -m "KlikTahu: $EPISODE" 2>/dev/null || true
  git branch -M main
  git remote remove origin 2>/dev/null || true
  git remote add origin "https://${GH_USER}:${GH_TOKEN}@github.com/${GH_USER}/${REPO}.git"
  git push -u origin main --force
  git remote set-url origin "https://github.com/${GH_USER}/${REPO}.git"   # rahasia jangan tersimpan
}

cmd_render() {
  CH="${1:-12}"; JB="${2:-4}"
  api -o /tmp/wf.json -w "trigger -> %{http_code}\n" -X POST \
    "$API/repos/$GH_USER/$REPO/actions/workflows/render.yml/dispatches" \
    -d "{\"ref\":\"main\",\"inputs\":{\"episode\":\"$EPISODE\",\"chunks\":\"$CH\",\"jobs\":\"$JB\",\"make_release\":true}}"
  sleep 6
  cmd_watch
}

cmd_watch() {
  echo "memantau run terbaru…"
  for i in $(seq 1 120); do
    api "$API/repos/$GH_USER/$REPO/actions/runs?per_page=1" > /tmp/runs.json
    read -r id st concl < <(python3 - <<'PY'
import json
r=json.load(open('/tmp/runs.json'))['workflow_runs'][0]
print(r['id'], r['status'], r.get('conclusion') or '-')
PY
)
    echo "  [$i] run $id status=$st conclusion=$concl"
    case "$st" in completed) [ "$concl" = success ] && { echo "SELESAI ✔"; break; } || { echo "GAGAL ✘ — cek log: https://github.com/$GH_USER/$REPO/actions"; exit 1; }; esac
    sleep 25
  done
}

cmd_fetch() {
  api "$API/repos/$GH_USER/$REPO/releases/latest" > /tmp/rel.json
  python3 - <<'PY' > /tmp/dl.txt
import json
r=json.load(open('/tmp/rel.json'))
for a in r.get('assets',[]):
    print(a['browser_download_url'], a['name'])
PY
  [ -s /tmp/dl.txt ] || { echo "belum ada release"; exit 1; }
  while read -r url name; do
    echo "unduh $name"
    curl -sSL "${AUTH[@]}" -o "/home/user/$name" "$url"
  done < /tmp/dl.txt
  ls -la /home/user/*.mp4 /home/user/*.md 2>/dev/null || true
}

case "${1:-all}" in
  list)   cmd_list ;;
  mkrepo) cmd_mkrepo ;;
  push)   cmd_push ;;
  render) shift; cmd_render "$@" ;;
  watch)  cmd_watch ;;
  fetch)  cmd_fetch ;;
  all)    cmd_list; cmd_mkrepo; cmd_push; cmd_render "${2:-12}" "${3:-4}"; cmd_fetch ;;
  *) echo "pakai: $0 {list|mkrepo|push|render [chunks] [jobs]|watch|fetch|all}" ;;
esac
